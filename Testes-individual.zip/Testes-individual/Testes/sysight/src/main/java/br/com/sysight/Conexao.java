package br.com.sysight;

import org.apache.commons.dbcp2.BasicDataSource;


public class Conexao {

 private BasicDataSource datasource;

public Conexao() {
        this.datasource = new BasicDataSource();
        datasource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        datasource.setUrl("jdbc:sqlserver://sistemaope.database.windows.net;" +
                    "databaseName=ac3-marise;");
        datasource.setUsername("Matheus");
        datasource.setPassword("170501ma@");

    }
 

 public BasicDataSource getDatasource() {
  return datasource;
 }

}